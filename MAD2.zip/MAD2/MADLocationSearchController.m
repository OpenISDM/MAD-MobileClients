//
//  MADLocationSearchController.m
//  MAD2
//
//  Created by Derrick Cheng on 8/1/12.
//  Copyright (c) 2012 UC Berkeley EECS. All rights reserved.
//

#import "MADLocationSearchController.h"

@implementation MADLocationSearchController

@end
