//
//  MADLocationTableViewCell.m
//  MAD2
//
//  Created by Derrick Cheng on 8/5/12.
//  Copyright (c) 2012 UC Berkeley EECS. All rights reserved.
//

#import "MADLocationTableViewCell.h"

@implementation MADLocationTableViewCell

@synthesize distanceLabel = _distanceLabel;
@synthesize titleLabel = _titleLabel;

@end
