//
//  MADSearchBar.m
//  MAD2
//
//  Created by Derrick Cheng on 8/5/12.
//  Copyright (c) 2012 UC Berkeley EECS. All rights reserved.
//

#import "MADSearchBar.h"

@implementation MADSearchBar

- (void) setShowsScopeBar:(BOOL)showsScopeBar
{
    [super setShowsScopeBar:YES];
}

@end
