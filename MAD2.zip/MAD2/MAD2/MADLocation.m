//
//  MADLocation.m
//  MAD2
//
//  Created by Derrick Cheng on 7/23/12.
//  Copyright (c) 2012 UC Berkeley EECS. All rights reserved.
//

#import "MADLocation.h"
#import "MAD2AppDelegate.h"


@implementation MADLocation

@dynamic name;
@dynamic lon;
@dynamic lat;
@dynamic detail;
@dynamic type;
@dynamic dateAdded;

@end
