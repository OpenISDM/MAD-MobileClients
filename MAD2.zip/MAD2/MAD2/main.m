//
//  main.m
//  MAD2
//
//  Created by Derrick Cheng on 7/23/12.
//  Copyright (c) 2012 UC Berkeley EECS. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MAD2AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MAD2AppDelegate class]));
    }
}
