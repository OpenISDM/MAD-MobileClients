//
//  MADSearchBar.h
//  MAD2
//
//  Created by Derrick Cheng on 8/5/12.
//  Copyright (c) 2012 UC Berkeley EECS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MADSearchBar : UISearchBar

@end
